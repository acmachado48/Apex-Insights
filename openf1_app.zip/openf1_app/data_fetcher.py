import requests
import json

# Função para buscar os dados da corrida usando a API OpenF1
def get_race_data(race_id):
    url = f"https://api.openf1.com/races/{race_id}/data"  # Exemplo de endpoint, ajuste conforme a documentação real da OpenF1
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        raise ValueError(f"Erro ao buscar dados da corrida: {response.status_code}")

# Função para buscar as voltas dos pilotos (exemplo simplificado)
def get_lap_data(race_id):
    race_data = get_race_data(race_id)
    laps = race_data['laps']  # Ajuste o caminho do JSON conforme os dados reais da API
    lap_times = {}
    for lap in laps:
        lap_times[lap['driver']] = lap['time']
    return lap_times

# Função para buscar a posição dos carros ao vivo
def get_live_positions(race_id):
    race_data = get_race_data(race_id)
    positions = race_data['positions']  # Ajuste conforme a estrutura real dos dados
    return positions

# Função para buscar a posição de um piloto específico
def get_live_position(race_id, driver_id):
    positions = get_live_positions(race_id)
    for position in positions:
        if position['driver'] == driver_id:
            return position
    return None


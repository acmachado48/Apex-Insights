import plotly.graph_objects as go
from data_fetcher import get_lap_data

# Função para criar o gráfico de evolução de posição
def show_position_chart(race_id):
    lap_data = get_lap_data(race_id)
    
    # Inicializa um dicionário para armazenar as posições por volta de cada piloto
    positions_by_driver = {}

    # Preenche as posições por piloto
    for lap, data in lap_data.items():
        for driver, position in data.items():
            if driver not in positions_by_driver:
                positions_by_driver[driver] = []
            positions_by_driver[driver].append(position)

    # Criação do gráfico de evolução de posições
    fig = go.Figure()

    # Para cada piloto, adiciona uma linha no gráfico
    for driver, positions in positions_by_driver.items():
        fig.add_trace(go.Scatter(
            x=list(lap_data.keys()),  # As voltas
            y=positions,              # As posições do piloto
            mode='lines+markers',     # Marca as posições nas voltas
            name=driver
        ))


    # Atualiza o layout d gráfico
    fig.update_layout(
        title="📊 Evolução de Posições dos Pilotos",
        xaxis_title="Voltas",
        yaxis_title="Posição",
        yaxis=dict(range=[0, 25], autorange="reversed"),  # Posição 1 está no topo
        showlegend=True
    )

    # Exibe o gráfico
    fig.show()


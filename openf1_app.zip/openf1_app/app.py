import streamlit as st
from data_fetcher import get_lap_data
from visualizer import show_live_grid
from overtakes import show_overtake_ranking
from position_graph import show_position_chart

st.set_page_config(layout="wide")
st.title("🏎️ OpenF1 - Visualização de Corrida em Tempo Real")

st.sidebar.title("Menu")
option = st.sidebar.radio("Escolha uma visualização:", [
    "Grid ao Vivo",
    "Ranking de Ultrapassagens",
    "Evolução de Posições"
])

race_id = st.sidebar.text_input("Race ID (ex: 1093 para Bahrain 2024)", value="1093")

if option == "Grid ao Vivo":
    show_live_grid(race_id)
elif option == "Ranking de Ultrapassagens":
    show_overtake_ranking(race_id)
elif option == "Evolução de Posições":
    show_position_chart(race_id)
